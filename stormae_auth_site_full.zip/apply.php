<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<title>نموذج التقديم</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h1>نموذج تقديم الإدارة</h1>
<form action="submit_application.php" method="POST">
    <label>اسمك في اللعبة أو الديسكورد:</label><br>
    <input type="text" name="name" required><br><br>

    <label>سبب التقديم:</label><br>
    <textarea name="reason" required></textarea><br><br>

    <button type="submit">أرسل التقديم</button>
</form>
</div>
</body>
</html>

<?php
$client_id = 'YOUR_CLIENT_ID';
$redirect_uri = urlencode('https://yourdomain.com/callback.php');
$scope = urlencode('identify');

$discord_login_url = "https://discord.com/api/oauth2/authorize?client_id=$client_id&redirect_uri=$redirect_uri&response_type=code&scope=$scope";

header("Location: $discord_login_url");
exit();
?>

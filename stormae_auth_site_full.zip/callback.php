<?php
session_start();

$client_id = 'YOUR_CLIENT_ID';
$client_secret = 'YOUR_CLIENT_SECRET';
$redirect_uri = 'https://yourdomain.com/callback.php';

if (!isset($_GET['code'])) {
    die('No code provided');
}

$code = $_GET['code'];

// طلب توكن الوصول
$token_url = "https://discord.com/api/oauth2/token";

$data = [
    'client_id' => $client_id,
    'client_secret' => $client_secret,
    'grant_type' => 'authorization_code',
    'code' => $code,
    'redirect_uri' => $redirect_uri,
    'scope' => 'identify'
];

$options = [
    'http' => [
        'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query($data),
    ],
];

$context  = stream_context_create($options);
$response = file_get_contents($token_url, false, $context);
if ($response === FALSE) {
    die('Error getting access token');
}

$token = json_decode($response, true);
$access_token = $token['access_token'];

// جلب بيانات المستخدم
$user_url = "https://discord.com/api/users/@me";

$opts = [
    "http" => [
        "method" => "GET",
        "header" => "Authorization: Bearer $access_token\r\n"
    ]
];

$context = stream_context_create($opts);
$user_response = file_get_contents($user_url, false, $context);
if ($user_response === FALSE) {
    die('Error getting user data');
}

$user = json_decode($user_response, true);

// حفظ بيانات المستخدم في الجلسة
$_SESSION['discord_id'] = $user['id'];
$_SESSION['username'] = $user['username'] . '#' . $user['discriminator'];

// قراءة ملف الرتب اللي جلبها البوت
$roles_file = __DIR__ . '/roles.json';
$roles_data = [];

if (file_exists($roles_file)) {
    $roles_data = json_decode(file_get_contents($roles_file), true);
} else {
    die('Roles data not found. Please run the bot first.');
}

$user_roles = $roles_data[$_SESSION['discord_id']] ?? [];

$allowed_roles = ['co founder', 'founder', 'owner'];

// تحويل كل الرتب لصغير للمقارنة
$user_roles_lower = array_map('strtolower', $user_roles);

$has_full_access = false;
foreach ($allowed_roles as $role) {
    if (in_array(strtolower($role), $user_roles_lower)) {
        $has_full_access = true;
        break;
    }
}

if ($has_full_access) {
    $_SESSION['role'] = 'full_access';
} else {
    $_SESSION['role'] = 'viewer';
}

header('Location: dashboard.php');
exit();
?>

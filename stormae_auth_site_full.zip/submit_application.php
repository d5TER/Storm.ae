<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $reason = $_POST['reason'] ?? '';
    $time = date('Y-m-d H:i:s');

    $application = [
        'name' => htmlspecialchars($name),
        'reason' => htmlspecialchars($reason),
        'time' => $time
    ];

    $file = 'applications.json';

    $applications = [];
    if (file_exists($file)) {
        $applications = json_decode(file_get_contents($file), true);
    }

    $applications[] = $application;
    file_put_contents($file, json_encode($applications, JSON_PRETTY_PRINT));

    echo "<!DOCTYPE html>
    <html lang='ar'>
    <head>
    <meta charset='UTF-8'>
    <title>تم الإرسال</title>
    <link rel='stylesheet' href='style.css'>
    </head>
    <body>
    <div class='container'>
    <h1>تم إرسال طلبك بنجاح.</h1>
    <p><a href='apply.php'>رجوع للنموذج</a></p>
    </div>
    </body>
    </html>";
} else {
    echo "طريقة غير صحيحة.";
}
?>

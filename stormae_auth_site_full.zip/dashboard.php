<?php
session_start();

if (!isset($_SESSION['discord_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SESSION['role'] !== 'full_access') {
    echo "<div class='container'>";
    echo "<h1>ما عندك صلاحيات كافية للوصول لهذه الصفحة.</h1>";
    echo "<p><a href='logout.php'>تسجيل خروج</a></p>";
    echo "</div>";
    exit();
}

// هنا تضع كود عرض التقديمات وقبول/رفض/حذف
echo "<!DOCTYPE html>
<html lang='ar'>
<head>
<meta charset='UTF-8'>
<title>لوحة التحكم</title>
<link rel='stylesheet' href='style.css'>
</head>
<body>
<div class='container'>
<h1>مرحبا بك، " . htmlspecialchars($_SESSION['username']) . "</h1>
<p>أنت تملك صلاحيات كاملة.</p>

<p><a href='logout.php'>تسجيل خروج</a></p>
</div>
</body>
</html>";
?>
